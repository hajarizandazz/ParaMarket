<?php 
session_start();
$conn = mysqli_connect("127.0.0.1:3308", "root", "", "pfe");



?>